import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface User {
  id: number;
  username: string;
  display_name: string;
  profile_photo?: string;
  bio?: string;
  join_date?: string;
  friendCount?: number;
  isAdmin?: boolean;
  friendship_status?: 'pending' | 'accepted' | 'rejected' | null;
  unread_count?: number;
}

export interface Message {
  id: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  type: 'text' | 'image' | 'video' | 'file' | 'voice';
  file_url?: string;
  is_read: number;
  created_at: string;
}

export interface FriendRequest {
  id: number;
  sender_id: number;
  receiver_id: number;
  status: 'pending' | 'accepted' | 'rejected';
  username: string;
  display_name: string;
  profile_photo?: string;
}
