/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, Users, User, Settings, Search, 
  Send, Image as ImageIcon, Video, Mic, Phone, 
  Video as VideoIcon, MoreVertical, ArrowLeft,
  Check, CheckCheck, Paperclip, Smile, Shield,
  LogOut, Ban, Trash2, UserPlus, X, PhoneOff,
  Camera, CameraOff, MicOff, Volume2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { io, Socket } from 'socket.io-client';
import { format } from 'date-fns';
import { cn, User as UserType, Message, FriendRequest } from './types';

// --- Components ---

const Button = ({ className, variant = 'primary', ...props }: any) => {
  const variants = {
    primary: 'bg-indigo-600 text-white hover:bg-indigo-700',
    secondary: 'bg-zinc-800 text-zinc-100 hover:bg-zinc-700',
    danger: 'bg-red-600 text-white hover:bg-red-700',
    ghost: 'bg-transparent text-zinc-400 hover:text-white hover:bg-white/5',
  };
  return (
    <button 
      className={cn('px-4 py-2 rounded-xl font-medium transition-all active:scale-95 disabled:opacity-50', variants[variant as keyof typeof variants], className)} 
      {...props} 
    />
  );
};

const Input = ({ className, ...props }: any) => (
  <input 
    className={cn('w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all', className)} 
    {...props} 
  />
);

// --- Main App ---

export default function App() {
  const [screen, setScreen] = useState<'splash' | 'auth' | 'main' | 'chat' | 'call' | 'admin'>('splash');
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [user, setUser] = useState<UserType | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [friends, setFriends] = useState<UserType[]>([]);
  const [activeChat, setActiveChat] = useState<UserType | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserType[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState<'chats' | 'friends' | 'settings'>('chats');
  const [showAdminAuth, setShowAdminAuth] = useState(false);
  const [adminAuthPassword, setAdminAuthPassword] = useState('');
  const notificationSound = useRef<HTMLAudioElement | null>(null);
  
  // WebRTC States
  const [isCalling, setIsCalling] = useState(false);
  const [callData, setCallData] = useState<any>(null);
  const [callAccepted, setCallAccepted] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const pendingIceCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const ringingSound = useRef<HTMLAudioElement | null>(null);

  const activeChatRef = useRef<UserType | null>(null);

  useEffect(() => {
    activeChatRef.current = activeChat;
    if (activeChat) {
      markAsRead(activeChat.id);
    }
  }, [activeChat]);

  useEffect(() => {
    notificationSound.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2354/2354-preview.mp3');
  }, []);

  const socketRef = useRef<Socket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (token) {
      const savedUser = localStorage.getItem('user');
      if (savedUser) {
        const u = JSON.parse(savedUser);
        setUser(u);
        setScreen('main');
        initSocket(u.id);
      }
    } else {
      setTimeout(() => setScreen('auth'), 2000);
    }
  }, [token]);

  useEffect(() => {
    if (screen === 'admin' && token) {
      fetchAdminUsers();
    }
  }, [screen, token]);

  useEffect(() => {
    if (token && user && screen === 'main') {
      fetchFriends();
      fetchRequests();
    }
  }, [token, user, screen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const initSocket = (userId: number) => {
    socketRef.current = io();
    socketRef.current.emit('authenticate', userId);
    
    socketRef.current.on('new_message', (msg: Message) => {
      const isActive = activeChatRef.current && (msg.sender_id === activeChatRef.current.id || msg.receiver_id === activeChatRef.current.id);
      
      if (isActive) {
        setMessages(prev => {
          if (prev.some(m => m.id === msg.id)) return prev;
          return [...prev, msg];
        });
        if (msg.sender_id === activeChatRef.current.id) {
          markAsRead(msg.sender_id);
        }
      } else if (msg.sender_id !== userId) {
        // Update unread count for the friend
        setFriends(prev => prev.map(f => f.id === msg.sender_id ? { ...f, unread_count: (f.unread_count || 0) + 1 } : f));
      }
      
      // Play sound for incoming messages
      if (msg.sender_id !== userId) {
        notificationSound.current?.play().catch(e => console.log('Sound play error:', e));
      }
    });

    socketRef.current.on('messages_read', ({ readerId }) => {
      if (activeChatRef.current && readerId === activeChatRef.current.id) {
        setMessages(prev => prev.map(m => m.receiver_id === readerId ? { ...m, is_read: 1 } : m));
      }
    });

    socketRef.current.on('typing', ({ senderId }) => {
      if (activeChatRef.current && senderId === activeChatRef.current.id) {
        setIsTyping(true);
        setTimeout(() => setIsTyping(false), 3000);
      }
    });

    socketRef.current.on('incoming_call', ({ offer, from, type }) => {
      setCallData({ type, from, offer, isOutgoing: false });
      setScreen('call');
      ringingSound.current?.play().catch(e => console.log('Sound play error:', e));
    });

    socketRef.current.on('call_accepted', async ({ answer }) => {
      ringingSound.current?.pause();
      ringingSound.current!.currentTime = 0;
      setCallAccepted(true);
      if (pcRef.current && pcRef.current.signalingState !== 'stable') {
        try {
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(answer));
          // Process pending candidates
          while (pendingIceCandidatesRef.current.length > 0) {
            const candidate = pendingIceCandidatesRef.current.shift();
            if (candidate) await pcRef.current.addIceCandidate(new RTCIceCandidate(candidate));
          }
        } catch (e) {
          console.error('Error setting remote description:', e);
        }
      }
    });

    socketRef.current.on('ice_candidate', async ({ candidate }) => {
      if (pcRef.current && pcRef.current.remoteDescription) {
        try {
          await pcRef.current.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (e) {
          console.error('Error adding ice candidate:', e);
        }
      } else {
        pendingIceCandidatesRef.current.push(candidate);
      }
    });

    socketRef.current.on('call_ended', () => {
      ringingSound.current?.pause();
      ringingSound.current!.currentTime = 0;
      
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
      if (pcRef.current) {
        pcRef.current.close();
        pcRef.current = null;
      }

      setLocalStream(null);
      setRemoteStream(null);
      setIsCalling(false);
      setCallData(null);
      setCallAccepted(false);
      setScreen('chat');
    });

    socketRef.current.on('new_friend_request', (sender) => {
      setRequests(prev => [...prev, { ...sender, status: 'pending', id: Date.now() }]); // Temporary ID for UI
      fetchRequests(); // Refetch to get real ID
    });

    socketRef.current.on('friend_request_accepted', () => {
      fetchFriends();
    });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: (form.elements.namedItem('username') as HTMLInputElement).value,
        password: (form.elements.namedItem('password') as HTMLInputElement).value,
      })
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setToken(data.token);
    } else {
      alert(data.error);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: (form.elements.namedItem('username') as HTMLInputElement).value,
        password: (form.elements.namedItem('password') as HTMLInputElement).value,
        display_name: (form.elements.namedItem('display_name') as HTMLInputElement).value,
        dob: (form.elements.namedItem('dob') as HTMLInputElement).value,
        bio: (form.elements.namedItem('bio') as HTMLInputElement).value,
      })
    });
    const data = await res.json();
    if (data.id) {
      setAuthMode('login');
      alert('Registration successful! Please login.');
    } else {
      alert(data.error);
    }
  };

  const fetchFriends = async () => {
    const res = await fetch('/api/friends', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setFriends(data);
  };

  const fetchRequests = async () => {
    const res = await fetch('/api/friends/requests', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setRequests(data);
  };

  const searchUsers = async (q: string) => {
    if (!q) return setSearchResults([]);
    const res = await fetch(`/api/users/search?q=${q}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setSearchResults(data);
  };

  const sendRequest = async (receiverId: number) => {
    const res = await fetch('/api/friends/request', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ receiverId })
    });
    const data = await res.json();
    if (data.success) {
      alert('Friend request sent successfully! ✅');
      // Update search results to show pending
      setSearchResults(prev => prev.map(u => u.id === receiverId ? { ...u, friendship_status: 'pending' } : u));
    } else {
      alert(data.error || 'Failed to send request');
    }
  };

  const markAsRead = async (senderId: number) => {
    if (!token) return;
    await fetch('/api/messages/read', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ senderId })
    });
  };

  const respondRequest = async (requestId: number, status: 'accepted' | 'rejected') => {
    await fetch('/api/friends/respond', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ requestId, status })
    });
    fetchRequests();
    fetchFriends();
  };

  const startChat = async (otherUser: UserType) => {
    setActiveChat(otherUser);
    setScreen('chat');
    setFriends(prev => prev.map(f => f.id === otherUser.id ? { ...f, unread_count: 0 } : f));
    const res = await fetch(`/api/messages/${otherUser.id}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setMessages(data);
    markAsRead(otherUser.id);
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const input = form.elements.namedItem('message') as HTMLInputElement;
    if (!activeChat || !input.value) return;
    
    const isFriend = friends.some(f => f.id === activeChat.id) || activeChat.friendship_status === 'accepted';
    if (!isFriend) {
      alert('You must be friends to send messages');
      return;
    }

    const res = await fetch('/api/messages/send', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        receiverId: activeChat.id,
        content: input.value,
        type: 'text'
      })
    });
    const data = await res.json();
    if (res.status === 403) {
      alert(data.error);
      return;
    }
    setMessages(prev => {
      if (prev.some(m => m.id === data.id)) return prev;
      return [...prev, data];
    });
    input.value = '';
  };

  const logout = () => {
    localStorage.clear();
    setToken(null);
    setUser(null);
    setScreen('auth');
    socketRef.current?.disconnect();
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video' | 'file') => {
    const file = e.target.files?.[0];
    if (!file || !activeChat) return;

    const isFriend = friends.some(f => f.id === activeChat.id) || activeChat.friendship_status === 'accepted';
    if (!isFriend) {
      alert('You must be friends to share files');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('receiverId', activeChat.id.toString());
    formData.append('type', type);

    const res = await fetch('/api/messages/send', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData
    });
    const data = await res.json();
    if (res.status === 403) {
      alert(data.error);
      return;
    }
    setMessages(prev => {
      if (prev.some(m => m.id === data.id)) return prev;
      return [...prev, data];
    });
  };

  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    if (!activeChat) return;
    
    const isFriend = friends.some(f => f.id === activeChat.id) || activeChat.friendship_status === 'accepted';
    if (!isFriend) {
      alert('You must be friends to send voice messages');
      return;
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    audioChunksRef.current = [];

    mediaRecorder.ondataavailable = (e) => {
      audioChunksRef.current.push(e.data);
    };

    mediaRecorder.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      const file = new File([audioBlob], 'voice-message.webm', { type: 'audio/webm' });
      
      const formData = new FormData();
      formData.append('file', file);
      formData.append('receiverId', activeChat!.id.toString());
      formData.append('type', 'voice');

      const res = await fetch('/api/messages/send', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const data = await res.json();
      setMessages(prev => [...prev, data]);
      stream.getTracks().forEach(track => track.stop());
    };

    mediaRecorder.start();
    setIsRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const res = await fetch('/api/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: (form.elements.namedItem('username') as HTMLInputElement).value,
        dob: (form.elements.namedItem('dob') as HTMLInputElement).value,
        newPassword: (form.elements.namedItem('newPassword') as HTMLInputElement).value,
      })
    });
    const data = await res.json();
    if (data.success) {
      setAuthMode('login');
      alert('Password reset successful! Please login.');
    } else {
      alert(data.error);
    }
  };

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const res = await fetch('/api/profile/update', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData
    });
    const data = await res.json();
    if (data.success) {
      setIsEditingProfile(false);
      // Refresh user data
      const userRes = await fetch(`/api/profile/${user?.username}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const userData = await userRes.json();
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
    }
  };

  useEffect(() => {
    ringingSound.current = new Audio('https://assets.mixkit.co/active_storage/sfx/1350/1350-preview.mp3');
    ringingSound.current.loop = true;
  }, []);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  const createPeerConnection = (to: number) => {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });

    pc.onicecandidate = (event) => {
      if (event.candidate && socketRef.current) {
        socketRef.current.emit('ice_candidate', { candidate: event.candidate, to });
      }
    };

    pc.ontrack = (event) => {
      setRemoteStream(event.streams[0]);
    };

    pcRef.current = pc;
    return pc;
  };

  const startCall = async (type: 'audio' | 'video') => {
    if (!activeChat || !socketRef.current || !user) return;
    
    const isFriend = friends.some(f => f.id === activeChat.id) || activeChat.friendship_status === 'accepted';
    if (!isFriend) {
      alert('You must be friends to start a call');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: type === 'video' 
      });
      setLocalStream(stream);
      setIsCalling(true);
      setCallData({ type, from: activeChat, isOutgoing: true });
      setScreen('call');
      ringingSound.current?.play().catch(e => console.log('Sound play error:', e));

      const pc = createPeerConnection(activeChat.id);
      stream.getTracks().forEach(track => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      socketRef.current.emit('call_user', { 
        to: activeChat.id, 
        from: user, 
        type,
        offer 
      });
    } catch (err) {
      console.error('Failed to get media:', err);
      alert('Could not access camera/microphone');
    }
  };

  const answerCall = async () => {
    if (!callData || !socketRef.current || !user) return;

    try {
      ringingSound.current?.pause();
      ringingSound.current!.currentTime = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: true, 
        video: callData.type === 'video' 
      });
      setLocalStream(stream);
      setCallAccepted(true);

      const pc = createPeerConnection(callData.from.id);
      stream.getTracks().forEach(track => pc.addTrack(track, stream));

      await pc.setRemoteDescription(new RTCSessionDescription(callData.offer));
      // Process pending candidates
      while (pendingIceCandidatesRef.current.length > 0) {
        const candidate = pendingIceCandidatesRef.current.shift();
        if (candidate) await pc.addIceCandidate(new RTCIceCandidate(candidate));
      }
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      socketRef.current.emit('answer_call', { 
        answer, 
        to: callData.from.id 
      });
    } catch (err) {
      console.error('Failed to answer call:', err);
      endCall();
    }
  };

  const endCall = () => {
    ringingSound.current?.pause();
    ringingSound.current!.currentTime = 0;
    
    if (socketRef.current && (activeChat || callData)) {
      const to = activeChat?.id || callData?.from?.id;
      if (to) socketRef.current.emit('end_call', { to });
    }

    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    pendingIceCandidatesRef.current = [];

    setLocalStream(null);
    setRemoteStream(null);
    setIsCalling(false);
    setCallData(null);
    setCallAccepted(false);
    setScreen('chat');
  };
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [adminMessages, setAdminMessages] = useState<any[]>([]);
  const [adminTab, setAdminTab] = useState<'users' | 'messages'>('users');

  const fetchAdminUsers = async () => {
    const res = await fetch('/api/admin/users', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setAdminUsers(data);
  };

  const fetchAdminMessages = async () => {
    const res = await fetch('/api/admin/messages', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setAdminMessages(data);
  };

  const handleAdminAction = async (userId: number, action: string) => {
    await fetch('/api/admin/user-action', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ userId, action })
    });
    fetchAdminUsers();
  };

  // --- Render Screens ---

  if (screen === 'splash') {
    return (
      <div className="h-screen bg-zinc-950 flex flex-col items-center justify-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="w-24 h-24 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-indigo-500/20"
        >
          <MessageCircle className="w-12 h-12 text-white" />
        </motion.div>
        <motion.h1 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-6 text-3xl font-bold text-white tracking-tight"
        >
          Vchat
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ delay: 0.5 }}
          className="mt-2 text-zinc-400 text-sm"
        >
          Connect with permission
        </motion.p>
      </div>
    );
  }

  if (screen === 'auth') {
    return (
      <div className="min-h-screen bg-zinc-950 p-6 flex flex-col">
        <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">
              {authMode === 'login' ? 'Welcome Back' : authMode === 'register' ? 'Create Account' : 'Reset Password'}
            </h2>
            <p className="text-zinc-400">
              {authMode === 'login' ? 'Sign in to continue chatting' : authMode === 'register' ? 'Join the secure community' : 'Verify your identity'}
            </p>
          </div>

          <form onSubmit={authMode === 'login' ? handleLogin : authMode === 'register' ? handleRegister : handleForgotPassword} className="space-y-4">
            <Input name="username" placeholder="Username" required />
            {authMode !== 'forgot' && <Input name="password" type="password" placeholder="Password" required />}
            
            {authMode === 'register' && (
              <>
                <Input name="display_name" placeholder="Display Name" required />
                <Input name="dob" type="date" placeholder="Date of Birth" required />
                <textarea 
                  name="bio" 
                  placeholder="Bio" 
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all h-24"
                />
              </>
            )}

            {authMode === 'forgot' && (
              <>
                <Input name="dob" type="date" placeholder="Date of Birth" required />
                <Input name="newPassword" type="password" placeholder="New Password" required />
              </>
            )}

            <Button type="submit" className="w-full py-4 text-lg">
              {authMode === 'login' ? 'Login' : authMode === 'register' ? 'Register' : 'Reset Password'}
            </Button>
          </form>

          <div className="mt-6 text-center space-y-2">
            {authMode === 'login' ? (
              <>
                <button onClick={() => setAuthMode('register')} className="text-indigo-400 text-sm hover:underline">Don't have an account? Register</button>
                <br />
                <button onClick={() => setAuthMode('forgot')} className="text-zinc-500 text-sm hover:underline">Forgot password?</button>
              </>
            ) : (
              <button onClick={() => setAuthMode('login')} className="text-indigo-400 text-sm hover:underline">Already have an account? Login</button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'main') {
    return (
      <div className="h-screen bg-zinc-950 flex flex-col">
        {/* Admin Re-authentication Modal */}
        <AnimatePresence>
          {showAdminAuth && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-zinc-900 w-full max-w-sm rounded-3xl p-8 border border-zinc-800 shadow-2xl"
              >
                <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Shield className="w-8 h-8 text-red-500" />
                </div>
                <h2 className="text-2xl font-bold text-white text-center mb-2">Secure Admin Access</h2>
                <p className="text-zinc-500 text-center text-sm mb-8">Please enter the administrator password to continue.</p>
                
                <div className="space-y-4">
                  <Input 
                    type="password" 
                    placeholder="Admin Password" 
                    value={adminAuthPassword}
                    onChange={(e) => setAdminAuthPassword(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && adminAuthPassword === '2003') {
                        setScreen('admin');
                        fetchAdminUsers();
                        setShowAdminAuth(false);
                        setAdminAuthPassword('');
                      }
                    }}
                    className="bg-zinc-950 border-zinc-800 text-center text-lg tracking-widest"
                    autoFocus
                  />
                  <div className="flex gap-3">
                    <Button 
                      variant="secondary" 
                      onClick={() => { setShowAdminAuth(false); setAdminAuthPassword(''); }}
                      className="flex-1 py-3"
                    >
                      Cancel
                    </Button>
                    <Button 
                      variant="primary" 
                      onClick={() => {
                        if (adminAuthPassword === '2003') {
                          setScreen('admin');
                          fetchAdminUsers();
                          setShowAdminAuth(false);
                          setAdminAuthPassword('');
                        } else {
                          alert('Incorrect Admin Password');
                        }
                      }}
                      className="flex-1 py-3 bg-red-600 hover:bg-red-700"
                    >
                      Verify
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Header */}
        <header className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/50 backdrop-blur-xl sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">Vchat</h1>
          </div>
          <div className="flex items-center gap-2">
            {user?.isAdmin && (
              <Button variant="ghost" onClick={() => setShowAdminAuth(true)} className="p-2">
                <Shield className="w-5 h-5" />
              </Button>
            )}
            <Button variant="ghost" onClick={logout} className="p-2">
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </header>

        {/* Search */}
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
            <Input 
              placeholder="Search users by username..." 
              className="pl-12"
              value={searchQuery}
              onChange={(e: any) => {
                setSearchQuery(e.target.value);
                searchUsers(e.target.value);
              }}
            />
          </div>
          
          {searchResults.length > 0 && (
            <div className="mt-2 bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
              {searchResults.map(res => (
                <div key={res.id} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-zinc-800 rounded-full overflow-hidden">
                      {res.profile_photo ? <img src={res.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-2 text-zinc-600" />}
                    </div>
                    <div>
                      <p className="text-white font-medium">{res.display_name}</p>
                      <p className="text-zinc-500 text-xs">@{res.username}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {res.friendship_status === 'accepted' ? (
                      <Button variant="primary" onClick={() => startChat(res)} className="p-2 rounded-full">
                        <MessageCircle className="w-5 h-5" />
                      </Button>
                    ) : res.friendship_status === 'pending' ? (
                      <div className="p-2 text-zinc-500 italic text-xs">Pending</div>
                    ) : (
                      <Button variant="secondary" onClick={() => sendRequest(res.id)} className="p-2 rounded-full">
                        <UserPlus className="w-5 h-5" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Tabs Content */}
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {activeTab === 'chats' && (
            <div className="space-y-6">
              {/* Friend Requests Section */}
              {requests.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">Pending Requests</h3>
                    <Button variant="ghost" onClick={fetchRequests} className="text-[10px] p-1">Refresh</Button>
                  </div>
                  <div className="space-y-2">
                    {requests.map(req => (
                      <div key={req.id} className="bg-zinc-900/50 p-3 rounded-2xl flex items-center justify-between border border-zinc-800/50">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-zinc-800 rounded-full overflow-hidden">
                            {req.profile_photo ? <img src={req.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-2 text-zinc-600" />}
                          </div>
                          <div>
                            <p className="text-white text-sm font-medium">{req.display_name}</p>
                            <p className="text-zinc-500 text-xs">@{req.username}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="primary" onClick={() => respondRequest(req.id, 'accepted')} className="p-2 rounded-full">
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button variant="secondary" onClick={() => respondRequest(req.id, 'rejected')} className="p-2 rounded-full text-red-400">
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Chats Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">Recent Chats</h3>
                  <Button variant="ghost" onClick={fetchFriends} className="text-[10px] p-1">Refresh</Button>
                </div>
                {friends.length === 0 ? (
                  <div className="text-center py-12 bg-zinc-900/20 rounded-3xl border border-dashed border-zinc-800">
                    <MessageCircle className="w-12 h-12 text-zinc-800 mx-auto mb-4" />
                    <p className="text-zinc-500 text-sm">No conversations yet.<br/>Search users to start chatting.</p>
                  </div>
                ) : (
                  <div className="space-y-1">
                    {friends.map(friend => (
                      <button 
                        key={friend.id} 
                        onClick={() => startChat(friend)}
                        className="w-full p-4 flex items-center gap-4 hover:bg-white/5 rounded-2xl transition-colors text-left group"
                      >
                        <div className="relative">
                          <div className="w-14 h-14 bg-zinc-800 rounded-2xl overflow-hidden">
                            {friend.profile_photo ? <img src={friend.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-3 text-zinc-600" />}
                          </div>
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-zinc-950 rounded-full" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-baseline mb-1">
                            <h4 className="text-white font-semibold truncate">{friend.display_name}</h4>
                            <span className="text-zinc-600 text-[10px]">Just now</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-zinc-500 text-sm truncate flex-1">{friend.bio || 'Hey there! I am using Vchat.'}</p>
                            {friend.unread_count > 0 && (
                              <div className="ml-2 bg-indigo-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center shadow-lg shadow-indigo-500/20">
                                {friend.unread_count}
                              </div>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'friends' && (
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-zinc-500 text-[10px] font-bold uppercase tracking-widest">All Friends ({friends.length})</h3>
                  <Button variant="ghost" onClick={fetchFriends} className="text-[10px] p-1">Refresh</Button>
                </div>
                {friends.length === 0 ? (
                  <div className="text-center py-12 bg-zinc-900/20 rounded-3xl border border-dashed border-zinc-800">
                    <Users className="w-12 h-12 text-zinc-800 mx-auto mb-4" />
                    <p className="text-zinc-500 text-sm">No friends yet.<br/>Search users to add them.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {friends.map(friend => (
                      <div key={friend.id} className="p-3 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-zinc-800 rounded-2xl overflow-hidden">
                            {friend.profile_photo ? <img src={friend.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-2 text-zinc-600" />}
                          </div>
                          <div>
                            <p className="text-white font-medium">{friend.display_name}</p>
                            <p className="text-zinc-500 text-xs">@{friend.username}</p>
                          </div>
                        </div>
                        <Button variant="secondary" onClick={() => startChat(friend)} className="p-2 rounded-xl">
                          <MessageCircle className="w-5 h-5" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="p-6 bg-zinc-900/50 rounded-3xl border border-zinc-800/50 text-center">
                <div className="w-24 h-24 bg-zinc-800 rounded-3xl mx-auto mb-4 overflow-hidden relative group">
                  {user?.profile_photo ? <img src={user.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-6 text-zinc-600" />}
                  <button onClick={() => setIsEditingProfile(true)} className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Camera className="w-6 h-6 text-white" />
                  </button>
                </div>
                <h2 className="text-xl font-bold text-white">{user?.display_name}</h2>
                <p className="text-zinc-500 text-sm mb-6">@{user?.username}</p>
                <div className="flex flex-col gap-2">
                  <Button variant="secondary" onClick={() => setIsEditingProfile(true)} className="w-full py-3">Edit Profile</Button>
                  
                  {user?.isAdmin && (
                    <Button 
                      variant="primary" 
                      onClick={() => setShowAdminAuth(true)} 
                      className="w-full py-3 bg-red-600 hover:bg-red-700 border-none shadow-lg shadow-red-600/20"
                    >
                      <Shield className="w-4 h-4 mr-2 inline" />
                      Secure Admin Access
                    </Button>
                  )}

                  <Button variant="secondary" onClick={logout} className="w-full py-3 text-red-400">Logout</Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Nav */}
        <nav className="p-4 border-t border-zinc-800 flex justify-around bg-zinc-950/80 backdrop-blur-xl">
          <Button 
            variant="ghost" 
            onClick={() => setActiveTab('chats')}
            className={cn('flex flex-col items-center gap-1', activeTab === 'chats' ? 'text-indigo-500' : 'text-zinc-500')}
          >
            <MessageCircle className="w-6 h-6" />
            <span className="text-[10px] font-bold">Chats</span>
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => setActiveTab('friends')}
            className={cn('flex flex-col items-center gap-1', activeTab === 'friends' ? 'text-indigo-500' : 'text-zinc-500')}
          >
            <Users className="w-6 h-6" />
            <span className="text-[10px] font-bold">Friends</span>
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => setActiveTab('settings')}
            className={cn('flex flex-col items-center gap-1', activeTab === 'settings' ? 'text-indigo-500' : 'text-zinc-500')}
          >
            <Settings className="w-6 h-6" />
            <span className="text-[10px] font-bold">Settings</span>
          </Button>
        </nav>

        {/* Edit Profile Modal */}
        <AnimatePresence>
          {isEditingProfile && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-zinc-900 w-full max-w-md rounded-3xl p-6 border border-zinc-800"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-white">Edit Profile</h3>
                  <Button variant="ghost" onClick={() => setIsEditingProfile(false)} className="p-2"><X className="w-6 h-6" /></Button>
                </div>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="flex flex-col items-center mb-6">
                    <div className="w-24 h-24 bg-zinc-800 rounded-full overflow-hidden mb-2 relative group">
                      {user?.profile_photo ? <img src={user.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-6 text-zinc-700" />}
                      <label htmlFor="photo-upload" className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                        <Camera className="w-6 h-6 text-white" />
                      </label>
                    </div>
                    <input type="file" id="photo-upload" name="photo" className="hidden" accept="image/*" />
                    <p className="text-zinc-500 text-xs">Tap to change photo</p>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Display Name</label>
                    <Input name="display_name" defaultValue={user?.display_name} required />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Bio</label>
                    <textarea 
                      name="bio" 
                      defaultValue={user?.bio}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all h-24"
                    />
                  </div>
                  <Button type="submit" className="w-full py-4 mt-4">Save Changes</Button>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  if (screen === 'chat' && activeChat) {
    return (
      <div className="h-screen bg-zinc-950 flex flex-col">
        {/* Chat Header */}
        <header className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/50 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={() => setScreen('main')} className="p-2 -ml-2">
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="w-10 h-10 bg-zinc-800 rounded-full overflow-hidden">
              {activeChat.profile_photo ? <img src={activeChat.profile_photo} className="w-full h-full object-cover" /> : <User className="w-full h-full p-2 text-zinc-600" />}
            </div>
            <div>
              <h3 className="text-white font-bold leading-none">{activeChat.display_name}</h3>
              <p className="text-zinc-500 text-xs mt-1">
                {isTyping ? <span className="text-indigo-400">typing...</span> : 'online'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" onClick={() => startCall('audio')} className="p-2"><Phone className="w-5 h-5" /></Button>
            <Button variant="ghost" onClick={() => startCall('video')} className="p-2"><VideoIcon className="w-5 h-5" /></Button>
            <Button variant="ghost" className="p-2"><MoreVertical className="w-5 h-5" /></Button>
          </div>
        </header>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
          {messages.map((msg, i) => {
            const isMe = msg.sender_id === user?.id;
            return (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                key={msg.id} 
                className={cn('flex flex-col max-w-[80%]', isMe ? 'ml-auto items-end' : 'mr-auto items-start')}
              >
                <div className={cn(
                  'px-4 py-3 rounded-2xl text-sm shadow-lg overflow-hidden',
                  isMe ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-zinc-800 text-zinc-100 rounded-tl-none'
                )}>
                  {msg.type === 'text' && msg.content}
                  {msg.type === 'image' && (
                    <img src={msg.file_url} alt="Shared" className="max-w-full rounded-lg cursor-pointer hover:opacity-90" onClick={() => window.open(msg.file_url)} />
                  )}
                  {msg.type === 'video' && (
                    <video src={msg.file_url} controls className="max-w-full rounded-lg" />
                  )}
                  {msg.type === 'voice' && (
                    <audio src={msg.file_url} controls className="max-w-full" />
                  )}
                  {msg.type === 'file' && (
                    <a href={msg.file_url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-indigo-400 hover:underline">
                      <Paperclip className="w-4 h-4" />
                      <span>Download File</span>
                    </a>
                  )}
                </div>
                <div className="flex items-center gap-1 mt-1 px-1">
                  <span className="text-[10px] text-zinc-600">{format(new Date(msg.created_at), 'h:mm a')}</span>
                  {isMe && (
                    <div className="flex items-center gap-0.5">
                      {msg.is_read ? (
                        <>
                          <span className="text-[9px] text-indigo-400 font-bold uppercase tracking-tighter">Seen</span>
                          <CheckCheck className="w-3 h-3 text-indigo-400" />
                        </>
                      ) : (
                        <Check className="w-3 h-3 text-zinc-600" />
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Chat Input */}
        <div className="p-4 bg-zinc-950 border-t border-zinc-800">
          <form onSubmit={sendMessage} className="flex items-center gap-2">
            <div className="flex items-center">
              <input type="file" id="img-upload" className="hidden" accept="image/*" onChange={(e) => handleFileUpload(e, 'image')} />
              <label htmlFor="img-upload" className="p-2 text-zinc-400 hover:text-white cursor-pointer"><ImageIcon className="w-5 h-5" /></label>
              
              <input type="file" id="vid-upload" className="hidden" accept="video/*" onChange={(e) => handleFileUpload(e, 'video')} />
              <label htmlFor="vid-upload" className="p-2 text-zinc-400 hover:text-white cursor-pointer"><Video className="w-5 h-5" /></label>
              
              <input type="file" id="file-upload" className="hidden" onChange={(e) => handleFileUpload(e, 'file')} />
              <label htmlFor="file-upload" className="p-2 text-zinc-400 hover:text-white cursor-pointer"><Paperclip className="w-5 h-5" /></label>
            </div>
            <div className="flex-1 relative">
              <Input 
                name="message" 
                placeholder={isRecording ? "Recording..." : "Message..."} 
                className="pr-12 bg-zinc-900 border-none"
                autoComplete="off"
                disabled={isRecording}
                onChange={() => {
                  socketRef.current?.emit('typing', { senderId: user?.id, receiverId: activeChat.id });
                }}
              />
              <Button type="button" variant="ghost" className="absolute right-2 top-1/2 -translate-y-1/2 p-1">
                <Smile className="w-6 h-6" />
              </Button>
            </div>
            <Button 
              type="button" 
              variant="ghost" 
              className={cn('p-2 rounded-full', isRecording ? 'text-red-500 bg-red-500/10' : 'text-zinc-400')}
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              onTouchStart={startRecording}
              onTouchEnd={stopRecording}
            >
              <Mic className="w-6 h-6" />
            </Button>
            <Button type="submit" className="p-3 rounded-full bg-indigo-600 hover:bg-indigo-700">
              <Send className="w-6 h-6" />
            </Button>
          </form>
        </div>
      </div>
    );
  }

  if (screen === 'admin') {
    // This is a safety check, but the modal handles the entry
    if (!user?.isAdmin) {
      setScreen('main');
      return null;
    }
    return (
      <div className="h-screen bg-zinc-950 flex flex-col">
        <header className="p-4 border-b border-zinc-800 flex items-center gap-4">
          <Button variant="ghost" onClick={() => setScreen('main')} className="p-2"><ArrowLeft className="w-6 h-6" /></Button>
          <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
          <div className="ml-auto flex gap-2">
            <Button 
              variant={adminTab === 'users' ? 'primary' : 'secondary'} 
              onClick={() => { setAdminTab('users'); fetchAdminUsers(); }}
              className="px-4 py-2 text-xs"
            >
              Users
            </Button>
            <Button 
              variant={adminTab === 'messages' ? 'primary' : 'secondary'} 
              onClick={() => { setAdminTab('messages'); fetchAdminMessages(); }}
              className="px-4 py-2 text-xs"
            >
              Messages
            </Button>
            <Button variant="ghost" onClick={adminTab === 'users' ? fetchAdminUsers : fetchAdminMessages} className="p-2">Refresh</Button>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto p-4">
          {adminTab === 'users' ? (
            <div className="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 text-xs uppercase font-bold">
                    <th className="p-4">User</th>
                    <th className="p-4">Joined</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {adminUsers.map(u => (
                    <tr key={u.id} className="border-b border-zinc-800/50 text-zinc-300">
                      <td className="p-4">
                        <p className="font-bold">{u.display_name}</p>
                        <p className="text-zinc-500 text-xs">@{u.username}</p>
                      </td>
                      <td className="p-4 text-zinc-500">{format(new Date(u.join_date), 'MMM yyyy')}</td>
                      <td className="p-4">
                        {u.is_banned ? (
                          <span className="px-2 py-1 bg-red-500/10 text-red-500 rounded-full text-[10px] font-bold">Banned</span>
                        ) : (
                          <span className="px-2 py-1 bg-emerald-500/10 text-emerald-500 rounded-full text-[10px] font-bold">Active</span>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          <Button variant="ghost" onClick={() => handleAdminAction(u.id, u.is_banned ? 'unban' : 'ban')} className={cn('p-2', u.is_banned ? 'text-emerald-500' : 'text-red-500')}>
                            <Ban className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" onClick={() => handleAdminAction(u.id, 'delete')} className="p-2 text-zinc-500">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="space-y-4">
              {adminMessages.map(msg => (
                <div key={msg.id} className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-indigo-400 font-bold text-sm">{msg.sender_name}</span>
                      <span className="text-zinc-600 text-xs">to</span>
                      <span className="text-emerald-400 font-bold text-sm">{msg.receiver_name}</span>
                    </div>
                    <span className="text-zinc-600 text-[10px]">{format(new Date(msg.created_at), 'MMM d, h:mm a')}</span>
                  </div>
                  <div className="text-zinc-300 text-sm bg-zinc-950/50 p-3 rounded-xl border border-zinc-800/50">
                    {msg.type === 'text' && msg.content}
                    {msg.type !== 'text' && (
                      <div className="flex items-center gap-2 text-zinc-500 italic">
                        <Paperclip className="w-4 h-4" />
                        <span>Media File: {msg.type}</span>
                        {msg.file_url && <a href={msg.file_url} target="_blank" rel="noreferrer" className="text-indigo-500 hover:underline ml-auto">View</a>}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (screen === 'call' && callData) {
    return (
      <div className="h-screen bg-zinc-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        {/* Background Blur */}
        <div className="absolute inset-0 opacity-20 blur-3xl">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-indigo-600 rounded-full" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-emerald-600 rounded-full" />
        </div>

        {!callAccepted ? (
          <div className="z-10 text-center space-y-8">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative"
            >
              <div className="w-32 h-32 bg-zinc-900 rounded-full mx-auto overflow-hidden border-4 border-indigo-500/30 relative z-10">
                {callData.from.profile_photo ? (
                  <img src={callData.from.profile_photo} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-full h-full p-8 text-zinc-700" />
                )}
              </div>
              <div className="absolute inset-0 bg-indigo-500/20 rounded-full animate-ping" />
            </motion.div>
            
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">{callData.from.display_name}</h2>
              <p className="text-indigo-400 uppercase tracking-widest text-xs font-bold animate-pulse">
                {callData.isOutgoing ? `Calling (${callData.type})...` : `Incoming ${callData.type} call...`}
              </p>
            </div>

            <div className="flex gap-8 justify-center">
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={endCall}
                className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center shadow-2xl shadow-red-500/40"
              >
                <PhoneOff className="w-8 h-8 text-white" />
              </motion.button>
              
              {!callData.isOutgoing && (
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={answerCall}
                  className="w-20 h-20 bg-emerald-600 rounded-full flex items-center justify-center shadow-2xl shadow-emerald-500/40"
                >
                  {callData.type === 'video' ? <VideoIcon className="w-8 h-8 text-white" /> : <Phone className="w-8 h-8 text-white" />}
                </motion.button>
              )}
            </div>
          </div>
        ) : (
          <div className="fixed inset-0 bg-black z-50 flex flex-col">
            {/* Video Area */}
            <div className="flex-1 relative bg-zinc-900 overflow-hidden">
              {callData.type === 'video' ? (
                <>
                  {/* Remote Video (Full Screen) */}
                  <video 
                    ref={remoteVideoRef} 
                    autoPlay 
                    playsInline 
                    className="w-full h-full object-cover"
                  />
                  {/* Local Video (Picture in Picture) */}
                  <motion.div 
                    drag
                    dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
                    className="absolute top-6 right-6 w-32 h-48 bg-zinc-950 rounded-2xl border-2 border-white/10 shadow-2xl overflow-hidden z-20"
                  >
                    <video 
                      ref={localVideoRef} 
                      autoPlay 
                      playsInline 
                      muted 
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                </>
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center space-y-8">
                  <motion.div 
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="w-40 h-40 bg-indigo-600 rounded-full flex items-center justify-center shadow-2xl shadow-indigo-500/20"
                  >
                    <User className="w-20 h-20 text-white" />
                  </motion.div>
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-white">{callData.from.display_name}</h3>
                    <p className="text-indigo-400 font-mono mt-2">In Call</p>
                  </div>
                  {/* Hidden audio elements for voice calls */}
                  <video ref={remoteVideoRef} autoPlay playsInline className="hidden" />
                  <video ref={localVideoRef} autoPlay playsInline muted className="hidden" />
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="p-8 pb-12 flex justify-center gap-6 bg-zinc-950/80 backdrop-blur-xl border-t border-zinc-800/50">
              <Button 
                variant="secondary" 
                className="w-16 h-16 rounded-full flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 border-none"
                onClick={() => {
                  if (localStream) {
                    const audioTrack = localStream.getAudioTracks()[0];
                    if (audioTrack) audioTrack.enabled = !audioTrack.enabled;
                  }
                }}
              >
                <Mic className="w-6 h-6" />
              </Button>
              
              {callData.type === 'video' && (
                <Button 
                  variant="secondary" 
                  className="w-16 h-16 rounded-full flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 border-none"
                  onClick={() => {
                    if (localStream) {
                      const videoTrack = localStream.getVideoTracks()[0];
                      if (videoTrack) videoTrack.enabled = !videoTrack.enabled;
                    }
                  }}
                >
                  <Camera className="w-6 h-6" />
                </Button>
              )}

              <Button 
                variant="danger" 
                onClick={endCall} 
                className="w-16 h-16 rounded-full flex items-center justify-center bg-red-600 hover:bg-red-700 border-none shadow-lg shadow-red-600/20"
              >
                <PhoneOff className="w-6 h-6" />
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
}
