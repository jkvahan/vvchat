import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || 'vchat-secret-key-123';
const db = new Database('vchat.db');

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    display_name TEXT,
    dob TEXT,
    bio TEXT,
    profile_photo TEXT,
    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_admin INTEGER DEFAULT 0,
    is_banned INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS friend_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    status TEXT DEFAULT 'pending', -- pending, accepted, rejected
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    content TEXT,
    type TEXT DEFAULT 'text', -- text, image, video, file, voice
    file_url TEXT,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  );
`);

// Ensure fixed admin exists
const ADMIN_USERNAME = 'Shafiq';
const ADMIN_PASSWORD_PLAIN = '2003';
const existingAdmin = db.prepare('SELECT * FROM users WHERE username = ?').get(ADMIN_USERNAME) as any;
if (!existingAdmin) {
  const hashedAdminPassword = bcrypt.hashSync(ADMIN_PASSWORD_PLAIN, 10);
  db.prepare('INSERT INTO users (username, password, display_name, dob, bio, is_admin) VALUES (?, ?, ?, ?, ?, ?)')
    .run(ADMIN_USERNAME, hashedAdminPassword, 'Admin Shafiq', '2003-01-01', 'System Administrator', 1);
} else if (existingAdmin.is_admin === 0) {
  db.prepare('UPDATE users SET is_admin = 1 WHERE username = ?').run(ADMIN_USERNAME);
}

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(express.json());

// File Upload Setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = './uploads';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });
app.use('/uploads', express.static('uploads'));

// Auth Middleware
const authenticate = (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Helper to check friendship
const areFriends = (userId1: number, userId2: number) => {
  const friendship = db.prepare(`
    SELECT * FROM friend_requests 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) 
    AND status = 'accepted'
  `).get(userId1, userId2, userId2, userId1);
  return !!friendship;
};

// --- API Routes ---

// Auth
app.post('/api/register', (req, res) => {
  const { username, password, display_name, dob, bio } = req.body;
  if (username.toLowerCase() === 'shafiq') {
    return res.status(400).json({ error: 'Username reserved' });
  }
  try {
    const hashedPassword = bcrypt.hashSync(password, 10);
    const stmt = db.prepare('INSERT INTO users (username, password, display_name, dob, bio, is_admin) VALUES (?, ?, ?, ?, ?, ?)');
    const result = stmt.run(username, hashedPassword, display_name, dob, bio, 0);
    res.json({ id: result.lastInsertRowid });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user: any = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  if (user.is_banned) return res.status(403).json({ error: 'Account banned' });
  
  const token = jwt.sign({ id: user.id, username: user.username, isAdmin: user.is_admin }, JWT_SECRET);
  res.json({ token, user: { id: user.id, username: user.username, display_name: user.display_name, profile_photo: user.profile_photo, isAdmin: user.is_admin } });
});

app.post('/api/forgot-password', (req, res) => {
  const { username, dob, newPassword } = req.body;
  if (username.toLowerCase() === 'shafiq') {
    return res.status(403).json({ error: 'Admin password cannot be changed' });
  }
  const user: any = db.prepare('SELECT * FROM users WHERE username = ? AND dob = ?').get(username, dob);
  if (!user) return res.status(404).json({ error: 'User not found or DOB incorrect' });
  
  const hashedPassword = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, user.id);
  res.json({ success: true });
});

// Users
app.get('/api/users/search', authenticate, (req: any, res) => {
  const { q } = req.query;
  const users = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.profile_photo, u.bio,
    (SELECT status FROM friend_requests WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?)) as friendship_status
    FROM users u 
    WHERE u.username LIKE ? AND u.id != ? 
    LIMIT 10
  `).all(req.user.id, req.user.id, `%${q}%`, req.user.id);
  res.json(users);
});

app.get('/api/profile/:username', authenticate, (req, res) => {
  const user: any = db.prepare('SELECT id, username, display_name, profile_photo, bio, join_date FROM users WHERE username = ?').get(req.params.username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  
  const friendCount = db.prepare("SELECT COUNT(*) as count FROM friend_requests WHERE (sender_id = ? OR receiver_id = ?) AND status = 'accepted'").get(user.id, user.id);
  res.json({ ...user, friendCount: (friendCount as any).count });
});

app.post('/api/profile/update', authenticate, upload.single('photo'), (req: any, res) => {
  const { display_name, bio } = req.body;
  const photoUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
  
  if (photoUrl) {
    db.prepare('UPDATE users SET display_name = ?, bio = ?, profile_photo = ? WHERE id = ?').run(display_name, bio, photoUrl, req.user.id);
  } else {
    db.prepare('UPDATE users SET display_name = ?, bio = ? WHERE id = ?').run(display_name, bio, req.user.id);
  }
  res.json({ success: true });
});

// Friend Requests
app.post('/api/friends/request', authenticate, (req: any, res) => {
  const receiverId = parseInt(req.body.receiverId);
  const senderId = req.user.id;

  console.log(`Friend request attempt: from ${senderId} to ${receiverId}`);

  if (isNaN(receiverId)) {
    console.error('Invalid receiver ID:', req.body.receiverId);
    return res.status(400).json({ error: "Invalid receiver ID" });
  }

  if (senderId === receiverId) {
    return res.status(400).json({ error: "You cannot send a request to yourself" });
  }

  // Check if an active (pending or accepted) request already exists
  const existingRequest = db.prepare(`
    SELECT * FROM friend_requests 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) 
    AND (status = 'pending' OR status = 'accepted')
  `).get(senderId, receiverId, receiverId, senderId);
  
  if (existingRequest) {
    console.log('Request already exists:', existingRequest);
    return res.status(400).json({ error: "A request is already pending or you are already connected" });
  }

  try {
    console.log('Creating new friend request...');
    // If a rejected request existed, delete it first to allow a fresh one
    db.prepare("DELETE FROM friend_requests WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) AND status = 'rejected'").run(senderId, receiverId, receiverId, senderId);
    
    db.prepare('INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)').run(senderId, receiverId);
    
    // Notify receiver
    const sender = db.prepare('SELECT id, username, display_name, profile_photo FROM users WHERE id = ?').get(senderId);
    io.to(`user_${receiverId}`).emit('new_friend_request', sender);
    
    res.json({ success: true });
  } catch (err: any) {
    console.error('Friend request error:', err);
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/friends/requests', authenticate, (req: any, res) => {
  const requests = db.prepare(`
    SELECT fr.*, u.username, u.display_name, u.profile_photo 
    FROM friend_requests fr 
    JOIN users u ON fr.sender_id = u.id 
    WHERE fr.receiver_id = ? AND fr.status = 'pending'
  `).all(req.user.id);
  res.json(requests);
});

app.post('/api/friends/respond', authenticate, (req: any, res) => {
  const { requestId, status } = req.body; // accepted or rejected
  db.prepare('UPDATE friend_requests SET status = ? WHERE id = ? AND receiver_id = ?').run(status, requestId, req.user.id);
  
  if (status === 'accepted') {
    const request: any = db.prepare('SELECT * FROM friend_requests WHERE id = ?').get(requestId);
    if (request) {
      io.to(`user_${request.sender_id}`).emit('friend_request_accepted', { userId: req.user.id });
    }
  }
  
  res.json({ success: true });
});

app.post('/api/messages/read', authenticate, (req: any, res) => {
  const { senderId } = req.body;
  db.prepare('UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0')
    .run(senderId, req.user.id);
  
  // Notify sender that messages were read
  io.to(`user_${senderId}`).emit('messages_read', { readerId: req.user.id });
  
  res.json({ success: true });
});

app.get('/api/friends', authenticate, (req: any, res) => {
  const friends = db.prepare(`
    SELECT DISTINCT u.id, u.username, u.display_name, u.profile_photo, u.bio,
    (SELECT COUNT(*) FROM messages WHERE sender_id = u.id AND receiver_id = ? AND is_read = 0) as unread_count
    FROM users u
    JOIN friend_requests fr ON (fr.sender_id = u.id OR fr.receiver_id = u.id)
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?) 
    AND fr.status = 'accepted' 
    AND u.id != ?
  `).all(req.user.id, req.user.id, req.user.id, req.user.id);
  res.json(friends);
});

// Messages
app.get('/api/messages/:otherUserId', authenticate, (req: any, res) => {
  const messages = db.prepare(`
    SELECT * FROM messages 
    WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ORDER BY created_at ASC
  `).all(req.user.id, req.params.otherUserId, req.params.otherUserId, req.user.id);
  res.json(messages);
});

app.post('/api/messages/send', authenticate, upload.single('file'), (req: any, res) => {
  const { receiverId, content, type } = req.body;
  
  if (!areFriends(req.user.id, parseInt(receiverId))) {
    return res.status(403).json({ error: 'You must be friends to send messages' });
  }

  const fileUrl = req.file ? `/uploads/${req.file.filename}` : null;
  const result = db.prepare('INSERT INTO messages (sender_id, receiver_id, content, type, file_url) VALUES (?, ?, ?, ?, ?)')
    .run(req.user.id, receiverId, content, type, fileUrl);
  
  const newMessage = db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid);
  io.to(`user_${receiverId}`).emit('new_message', newMessage);
  res.json(newMessage);
});

// Admin
app.get('/api/admin/users', authenticate, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'Forbidden' });
  const users = db.prepare('SELECT id, username, display_name, is_banned, join_date FROM users').all();
  res.json(users);
});

app.post('/api/admin/user-action', authenticate, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'Forbidden' });
  const { userId, action } = req.body;
  if (action === 'ban') db.prepare('UPDATE users SET is_banned = 1 WHERE id = ?').run(userId);
  if (action === 'unban') db.prepare('UPDATE users SET is_banned = 0 WHERE id = ?').run(userId);
  if (action === 'delete') {
    db.prepare('DELETE FROM messages WHERE sender_id = ? OR receiver_id = ?').run(userId, userId);
    db.prepare('DELETE FROM friend_requests WHERE sender_id = ? OR receiver_id = ?').run(userId, userId);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  }
  res.json({ success: true });
});

app.get('/api/admin/messages', authenticate, (req: any, res) => {
  if (!req.user.isAdmin) return res.status(403).json({ error: 'Forbidden' });
  const messages = db.prepare(`
    SELECT m.*, u1.display_name as sender_name, u2.display_name as receiver_name 
    FROM messages m
    JOIN users u1 ON m.sender_id = u1.id
    JOIN users u2 ON m.receiver_id = u2.id
    ORDER BY m.created_at DESC
  `).all();
  res.json(messages);
});

// --- WebSockets ---
const userSockets = new Map();

io.on('connection', (socket) => {
  socket.on('authenticate', (userId) => {
    socket.join(`user_${userId}`);
    userSockets.set(userId, socket.id);
    io.emit('user_status', { userId, status: 'online' });
  });

  socket.on('typing', ({ senderId, receiverId }) => {
    io.to(`user_${receiverId}`).emit('typing', { senderId });
  });

  // WebRTC Signaling
  socket.on('call_user', ({ offer, to, from, type }) => {
    // Check friendship before allowing call
    if (areFriends(from.id, to)) {
      io.to(`user_${to}`).emit('incoming_call', { offer, from, type });
    }
  });

  socket.on('answer_call', ({ answer, to }) => {
    io.to(`user_${to}`).emit('call_accepted', { answer });
  });

  socket.on('ice_candidate', ({ candidate, to }) => {
    io.to(`user_${to}`).emit('ice_candidate', { candidate });
  });

  socket.on('end_call', ({ to }) => {
    io.to(`user_${to}`).emit('call_ended');
  });

  socket.on('disconnect', () => {
    for (const [userId, socketId] of userSockets.entries()) {
      if (socketId === socket.id) {
        userSockets.delete(userId);
        io.emit('user_status', { userId, status: 'offline' });
        break;
      }
    }
  });
});

// --- Vite Integration ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => res.sendFile(path.resolve(__dirname, 'dist', 'index.html')));
  }

  httpServer.listen(3000, '0.0.0.0', () => {
    console.log('Server running on http://localhost:3000');
  });
}

startServer();
